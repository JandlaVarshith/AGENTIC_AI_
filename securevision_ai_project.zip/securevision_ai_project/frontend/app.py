import streamlit as st
import requests
import os

st.set_page_config(page_title="SecureVision AI", page_icon="🔐", layout="wide")
st.title("🔐 SecureVision AI")
st.caption("Image Retrieval + Visual Q&A for Security Operations")

backend_url = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")

tab1, tab2, tab3 = st.tabs(["Visual Q&A", "Image Indexing", "Image Retrieval"])

with tab1:
    st.subheader("Ask a question about a security image")
    image = st.file_uploader("Upload image", type=["png", "jpg", "jpeg"], key="qa")
    question = st.text_input(
        "Question",
        "Does this screenshot contain any visible security risk?"
    )
    if st.button("Analyze Image") and image and question:
        response = requests.post(
            f"{backend_url}/analyze",
            files={"file": (image.name, image.getvalue(), image.type)},
            data={"question": question},
            timeout=120
        )
        st.json(response.json())

with tab2:
    st.subheader("Index an image for retrieval")
    image = st.file_uploader("Upload evidence image", type=["png", "jpg", "jpeg"], key="index")
    description = st.text_area(
        "Description / tags",
        "Windows event log, suspicious process, phishing email, network alert"
    )
    if st.button("Index Image") and image:
        response = requests.post(
            f"{backend_url}/index",
            files={"file": (image.name, image.getvalue(), image.type)},
            data={"description": description},
            timeout=60
        )
        st.json(response.json())

with tab3:
    st.subheader("Search indexed images")
    query = st.text_input("Search query", "phishing email screenshot")
    if st.button("Search"):
        response = requests.get(
            f"{backend_url}/search",
            params={"q": query},
            timeout=30
        )
        st.json(response.json())
