from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pathlib import Path
from uuid import uuid4
from PIL import Image
import io
from backend.services.vision_service import analyze_image
from backend.services.retrieval_service import add_document, search_documents

app = FastAPI(title="SecureVision AI API")
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

@app.get("/health")
def health():
    return {"status": "ok", "service": "SecureVision AI"}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...), question: str = Form(...)):
    content = await file.read()
    try:
        image = Image.open(io.BytesIO(content)).convert("RGB")
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid image file"})
    result = analyze_image(image, question)
    return {"filename": file.filename, "question": question, "answer": result}

@app.post("/index")
async def index_image(file: UploadFile = File(...), description: str = Form("")):
    content = await file.read()
    image_id = str(uuid4())
    path = UPLOAD_DIR / f"{image_id}_{file.filename}"
    path.write_bytes(content)
    add_document(image_id=image_id, filename=file.filename, description=description, path=str(path))
    return {"status": "indexed", "image_id": image_id, "filename": file.filename}

@app.get("/search")
def search(q: str):
    return {"query": q, "results": search_documents(q)}
