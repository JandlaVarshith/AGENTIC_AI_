from pathlib import Path

DOCUMENTS = []

def add_document(image_id: str, filename: str, description: str, path: str):
    DOCUMENTS.append({
        "image_id": image_id,
        "filename": filename,
        "description": description,
        "path": path
    })

def search_documents(query: str):
    query_terms = set(query.lower().split())
    scored = []
    for doc in DOCUMENTS:
        text = f"{doc['filename']} {doc['description']}".lower()
        score = sum(1 for term in query_terms if term in text)
        if score:
            scored.append({**doc, "score": score})
    return sorted(scored, key=lambda x: x["score"], reverse=True)
