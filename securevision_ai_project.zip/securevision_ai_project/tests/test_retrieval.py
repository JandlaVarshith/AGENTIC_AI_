from backend.services.retrieval_service import add_document, search_documents

def test_keyword_retrieval():
    add_document("1", "event.png", "Windows suspicious process event", "/tmp/event.png")
    results = search_documents("suspicious process")
    assert results
    assert results[0]["image_id"] == "1"
