# Architecture

```text
User
 |
 v
Streamlit UI
 |
 v
FastAPI Backend
 |----------------------|
 v                      v
Vision Analysis      Retrieval Service
 |                      |
 v                      v
Security Findings    Metadata / Vector DB
```

## Production improvements
- Replace in-memory retrieval with PostgreSQL + pgvector or Qdrant.
- Add image embeddings from a vision embedding model.
- Add authentication and role-based access control.
- Encrypt stored evidence.
- Add audit logging.
- Scan uploads for malware and enforce file size/type limits.
- Redact secrets and personal information.
- Add human approval before creating incidents or taking actions.
