# Security Controls

- Validate MIME type and file signatures.
- Limit upload size.
- Store files outside the public web root.
- Use random server-generated filenames.
- Apply least-privilege access.
- Do not expose API keys in frontend code.
- Log user, timestamp, query, and accessed evidence.
- Use retention and deletion policies.
- Treat model output as advisory, not authoritative.
- Require analyst verification for incident classification.
